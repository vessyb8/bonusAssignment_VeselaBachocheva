package org.example;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class App
{
    public static void main( String[] args )
    {
        try {
            // Specify the path to the orders file
            File file = new File("C:\\Users\\P50\\Desktop\\BonusAssignment\\input.txt");
            Scanner scanner = new Scanner(file);

            // Process each line in the file
            while (scanner.hasNextLine()) {
                String purchase = scanner.nextLine();
                String[] purchaseDetail = purchase.split(",");

                // Process the order details here
                // Your existing order processing logic goes here
                int quantity = 0;
                double standartUnitPrice = 0;
                double promUnitPrice = 0;
                double priceOrderedProducts = 0;
                double lineTotal = 0;
                double totalPriceBefClDisc=0;
                int basicClDisc = 0;
                double basicClDiscPrice = 0;
                int additionalVolDisc = 0;
                double additionalVolDiscPrice = 0;
                double orderTotalAmount = 0;

                String productName = "";

                int productID = 0;
                int clientID = Integer.parseInt(purchaseDetail[0]);

                    try {
                        // Load the Excel file
                        FileInputStream clPrFile = new FileInputStream("C:\\Users\\P50\\Desktop\\BonusAssignment\\clientsAndProducts.xlsx");
                        Workbook workbook = WorkbookFactory.create(clPrFile);


                        // Get the first sheet in the Excel file
                        Sheet sheetClients = workbook.getSheetAt(1);

                        // Define the ID and Name column indices
                        int clientIdColIndex = 0; // Assuming ID is in the first column (index 0)
                        int clNameColIndex = 1; // Assuming Name is in the second column (index 1)

                        // Search for the ID value and retrieve the corresponding name
                        int targetClId = clientID; // Replace 123 with the ID you want to search for
                        String clName = null;
                        for (Row row : sheetClients) {
                            Cell idCell = row.getCell(clientIdColIndex);
                            if (idCell != null && idCell.getCellType() == CellType.NUMERIC && idCell.getNumericCellValue() == targetClId) {
                                Cell nameCell = row.getCell(clNameColIndex);
                                if (nameCell != null) {
                                    clName = nameCell.getStringCellValue();
                                    break; // Exit loop once name is found
                                }
                            }
                        }
                        if (clName != null) {
                            System.out.printf("Client       " + clName + "%n");
                            System.out.printf("%-20s | %-8s | %19s | %6s | %22s %n", "Product", "Quantity", "Standart Unit Price","Promotional Unit Price","Line Total");
                            for (int i = 1; i < purchaseDetail.length; i++) {
                                String[] productDetail = purchaseDetail[i].split("=");
                                productID = Integer.parseInt(productDetail[0]);
                                quantity = Integer.parseInt(productDetail[1]);

                                switch (productID) {
                                    case 1 -> {
                                        standartUnitPrice = Math.round((0.52 * 1.8) * 100.0) / 100.0;
                                        promUnitPrice = 0;
                                        priceOrderedProducts = standartUnitPrice * quantity;
                                        lineTotal = priceOrderedProducts - promUnitPrice;
                                    }
                                    case 2 -> {
                                        standartUnitPrice = Math.round((0.38 * 2.2) * 100.0) / 100.0;
                                        promUnitPrice = standartUnitPrice - standartUnitPrice * 0.3;
                                        priceOrderedProducts = standartUnitPrice * quantity;
                                        lineTotal = priceOrderedProducts - promUnitPrice;
                                    }
                                    case 3 -> {
                                        standartUnitPrice = 0.41 + 0.90;
                                        promUnitPrice = 0;
                                        priceOrderedProducts = standartUnitPrice * quantity;
                                        lineTotal = priceOrderedProducts - promUnitPrice;
                                    }
                                    case 4 -> {
                                        standartUnitPrice = 0.60 + 1.00;
                                        int numberFreeChips = quantity / 3;
                                        priceOrderedProducts = standartUnitPrice * quantity;
                                        promUnitPrice = (priceOrderedProducts - (numberFreeChips * standartUnitPrice)) / quantity;
                                        lineTotal = priceOrderedProducts - (numberFreeChips * standartUnitPrice);
                                    }
                                }

                                totalPriceBefClDisc += lineTotal;

                                // Get the first sheet in the Excel file
                                Sheet sheetProducts = workbook.getSheetAt(0);

                                // Define the ID and Name column indices
                                int productIdColIndex = 0; // Assuming ID is in the first column (index 0)
                                int prNameColIndex = 1; // Assuming Name is in the second column (index 1)

                                // Search for the ID value and retrieve the corresponding name
                                int targetPrId = productID; // Replace 123 with the ID you want to search for
                                String prName = null;
                                for (Row row : sheetProducts) {
                                    Cell idCell = row.getCell(productIdColIndex);
                                    if (idCell != null && idCell.getCellType() == CellType.NUMERIC && idCell.getNumericCellValue() == targetPrId) {
                                        Cell nameCell = row.getCell(prNameColIndex);
                                        if (nameCell != null) {
                                            prName = nameCell.getStringCellValue();
                                            break; // Exit loop once name is found
                                        }
                                    }
                                }
                                if (prName != null) {
                                    if (promUnitPrice > 0){
                                        System.out.printf("%-20s | %-8s | EUR%16.2f | EUR%19.5f | EUR%19.2f %n",prName, quantity, standartUnitPrice, promUnitPrice, lineTotal);
                                    }
                                    else {
                                        System.out.printf("%-20s | %-8s | EUR%16.2f | %-22s | EUR%19.2f %n",prName, quantity, standartUnitPrice, "", lineTotal);
                                    }
                                } else {
                                    System.out.println();
                                    System.out.println("Product name not found for ID " + targetPrId);
                                    System.out.println();
                                }
                            }

                            switch (clientID) {
                                case 1 :
                                    basicClDisc = 5;
                                    basicClDiscPrice = totalPriceBefClDisc * (basicClDisc / 100.00);
                                    if (totalPriceBefClDisc > 30000) {
                                        additionalVolDisc = 2;
                                        additionalVolDiscPrice = basicClDiscPrice * (additionalVolDisc / 100.0);
                                    }
                                    break;
                                case 2 :
                                    basicClDisc = 4;
                                    basicClDiscPrice = totalPriceBefClDisc*(basicClDisc/100.00);
                                    if (totalPriceBefClDisc > 10000 && totalPriceBefClDisc <=30000) {
                                        additionalVolDisc = 1;
                                        additionalVolDiscPrice = basicClDiscPrice*(additionalVolDisc/100.0);
                                    } else if (totalPriceBefClDisc > 30000) {
                                        additionalVolDisc = 2;
                                        additionalVolDiscPrice = basicClDiscPrice*(additionalVolDisc/100.0);
                                    }
                                    break;
                                case 3 :
                                    basicClDisc = 3;
                                    basicClDiscPrice = totalPriceBefClDisc*(basicClDisc/100.00);
                                    if (totalPriceBefClDisc > 10000 && totalPriceBefClDisc <=30000) {
                                        additionalVolDisc = 1;
                                        additionalVolDiscPrice = basicClDiscPrice*(additionalVolDisc/100.0);
                                    } else if (totalPriceBefClDisc > 30000) {
                                        additionalVolDisc = 3;
                                        additionalVolDiscPrice = basicClDiscPrice*(additionalVolDisc/100.0);
                                    }
                                    break;
                                case 4 :
                                    basicClDisc = 2;
                                    basicClDiscPrice = totalPriceBefClDisc*(basicClDisc/100.00);
                                    if (totalPriceBefClDisc > 10000 && totalPriceBefClDisc <=30000) {
                                        additionalVolDisc = 3;
                                        additionalVolDiscPrice = basicClDiscPrice*(additionalVolDisc/100.0);
                                    } else if (totalPriceBefClDisc > 30000) {
                                        additionalVolDisc = 5;
                                        additionalVolDiscPrice = basicClDiscPrice*(additionalVolDisc/100.0);
                                    }
                                    break;
                                case 5 :
                                    if (totalPriceBefClDisc > 10000 && totalPriceBefClDisc <=30000) {
                                        additionalVolDisc = 5;
                                        additionalVolDiscPrice = totalPriceBefClDisc*(additionalVolDisc/100.0);
                                    } else if (totalPriceBefClDisc > 30000) {
                                        additionalVolDisc = 7;
                                        additionalVolDiscPrice = totalPriceBefClDisc*(additionalVolDisc/100.0);
                                    }
                                    break;
                            }

                            orderTotalAmount = totalPriceBefClDisc - basicClDiscPrice - additionalVolDiscPrice;

                            System.out.printf("%n%-40s %s %.2f%n","Total Before Client Discounts:","EUR",totalPriceBefClDisc);
                            if (basicClDisc > 0){
                                System.out.printf("%s%d%%:%-12s %s %.2f%n","Basic Client Discount at ",basicClDisc,"","EUR", basicClDiscPrice);
                            }
                            if (additionalVolDisc > 0){
                                System.out.printf("%s%d%%:%-7s %s %.2f%n","Additional Volume Discount at ",additionalVolDisc,"","EUR",additionalVolDiscPrice);
                            }
                            System.out.printf("%-40s %s %.2f%n%n","Order Total Amount:","EUR", orderTotalAmount);
                        } else {
                            System.out.println("Client name not found for ID " + targetClId);
                            System.out.println();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }


                }
            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + e.getMessage());
        }
    }
}
